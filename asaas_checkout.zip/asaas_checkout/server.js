const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.json());
app.use(express.static(path.join(__dirname)));

const ASAAS_API_KEY = '$aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzM2MzE6OiRhYWNoXzU4NWIzNmIxLTNlYTQtNDdmMy05YTlmLTQyMjFjM2MwNDFhMg==';
const ASAAS_BASE_URL = 'https://api-sandbox.asaas.com/v3';

// WebSocket: quando o cliente conecta
io.on('connection', (socket) => {
  console.log('🧠 Cliente conectado via WebSocket:', socket.id);
});

// Função auxiliar: cria ou retorna cliente
async function getOrCreateCustomer({ cpf, fullName, emailFull, phoneFull }) {
  const cpfClean = cpf.replace(/\D/g, '');
  const phoneClean = phoneFull.replace(/\D/g, '');

  const search = await fetch(`${ASAAS_BASE_URL}/customers?cpfCnpj=${cpfClean}`, {
    headers: { 'access_token': ASAAS_API_KEY }
  });
  const result = await search.json();

  if (result.totalCount > 0) {
    return result.data[0].id;
  } else {
    const create = await fetch(`${ASAAS_BASE_URL}/customers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'access_token': ASAAS_API_KEY
      },
      body: JSON.stringify({ name: fullName, cpfCnpj: cpfClean, email: emailFull, phone: phoneClean })
    });
    const created = await create.json();
    return created.id;
  }
}

//Chamada para transação
app.post('/api/checkout', async (req, res) => {
  const {
    fullName,
    cpf,
    emailFull,
    phoneFull,
    paymentMethod,
    shirtSize,
    totalAmount,
    cardNumber,
    cardExpiry,
    cardCvv,
    cardInstallments
  } = req.body;

console.log('test')

  try {
    const customerId = await getOrCreateCustomer({ cpf, fullName, emailFull, phoneFull });
    const dueDate = new Date().toISOString().split('T')[0];

    let apiEndpoint = '';
    let payload = {};

    if (paymentMethod === 'CREDIT_CARD') {
      if (!cardNumber || !cardExpiry || !cardCvv || !cardInstallments) {
        return res.status(400).json({ success: false, message: 'Dados de cartão incompletos.' });
      }

      const [expiryMonth, expiryYear] = cardExpiry.split('/');

      payload = {
        billingType: 'CREDIT_CARD',
        customer: customerId,
        creditCard: {
          holderName: fullName,
          number: cardNumber,
          expiryMonth: expiryMonth,
          expiryYear: expiryYear,
          ccv: cardCvv
        },
        creditCardHolderInfo: {
          name: fullName,
          email: emailFull,
          cpfCnpj: cpf.replace(/\D/g, ''),
          phone: phoneFull.replace(/\D/g, '')
        },
        splits: [
          {
            walletId: 'cfea8b30-b429-4353-aa96-e6e20c3191fb',
            totalFixedValue: 250,
            description: 'Convenção Unificada Jovens e Música',
            externalReference: 'VPEMS202510'
          }
        ],
        installmentCount: parseInt(cardInstallments),
        totalValue: totalAmount,
        dueDate,
        description: `Ingresso Convenção + Camiseta (${shirtSize || 'sem camiseta'})`
      };

      apiEndpoint = `${ASAAS_BASE_URL}/installments`;
    } else if (paymentMethod === 'PIX') {
      payload = {
        billingType: 'PIX',
        customer: customerId,
        value: totalAmount,
        dueDate,
        split: [
          {
            walletId: 'cfea8b30-b429-4353-aa96-e6e20c3191fb',
            fixedValue: 250,
            description: 'Convenção Unificada Jovens e Música',
            externalReference: 'VPEMS202510'
          }
        ],
        description: `Ingresso Convenção + Camiseta (${shirtSize || 'sem camiseta'})`
      };

      apiEndpoint = `${ASAAS_BASE_URL}/payments`;
    } else {
      return res.status(400).json({ success: false, message: 'Forma de pagamento inválida.' });
    }
  
    console.log('Payload final:', JSON.stringify(payload));

    // console.log(apiEndpoint)

    const response = await fetch(apiEndpoint, {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        access_token: ASAAS_API_KEY
      },
      body: JSON.stringify(payload)
    });

    // console.log(response)

    const data = await response.json();

    if (data.errors) {
      return res.status(400).json({ success: false, message: data.errors[0].description });
    }

    // console.log(data.transactionReceiptUrl)

    res.json({
      success: true,
      paymentId: data.id || (data[0] && data[0].id),
      invoiceUrl: data.invoiceUrl || data.bankSlipUrl || data.paymentUrl || data.transactionReceiptUrl || null,
      pixQrCode: data.pixQrCode || null
    });

  } catch (err) {
    console.error('Erro no checkout:', err);
    res.status(500).json({ success: false, message: 'Erro interno no servidor.' });
  }
});

// Webhook Asaas com emissão via WebSocket
app.post('/api/webhook', express.json({ type: 'application/json' }), (req, res) => {
  res.status(200).json({ received: true }); // resposta rápida para o Asaas

  const payment = req.body;

  // Quando o Asaas envia diretamente o objeto de pagamento
  if (payment.object === 'payment' && payment.status === 'CONFIRMED') {
    console.log('✅ Pagamento confirmado:', payment.id);

    // Envia evento em tempo real para o cliente via WebSocket
    io.emit('payment-confirmed', payment.id);
  } else {
    console.log('📨 Webhook recebido, mas não confirmado:', payment.id, payment.status);
  }
});

// Inicializa o servidor com WebSocket
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Servidor rodando na porta ${PORT}`));
