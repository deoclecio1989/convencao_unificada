const express = require('express');
// const fetch = require('node-fetch');
const app = express();
app.use(express.json());

const path = require('path');
app.use(express.static(path.join(__dirname)));

const ASAAS_API_KEY = '$aact_YTU5YTE0M2M2N2I4MTliNzk0YTI5N2U5MzdjNWZmNDQ6OjAwMDAwMDAwMDAwMDAwNzM2MzE6OiRhYWNoXzU4NWIzNmIxLTNlYTQtNDdmMy05YTlmLTQyMjFjM2MwNDFhMg==';
const ASAAS_BASE_URL = 'https://api-sandbox.asaas.com/v3';

// Helper: cria ou retorna customerId
async function getOrCreateCustomer({ cpf, fullName, emailFull, phoneFull }) {
  const cpfClean = cpf.replace(/\D/g, '');
  const phoneClean = phoneFull.replace(/\D/g, '');

  const search = await fetch(`${ASAAS_BASE_URL}/customers?cpfCnpj=${cpfClean}`, {
    headers: { 'access_token': ASAAS_API_KEY }
  });
  const result = await search.json();

  if (result.totalCount > 0) {
    return result.data[0].id;
  } else {
    const create = await fetch(`${ASAAS_BASE_URL}/customers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'access_token': ASAAS_API_KEY
      },
      body: JSON.stringify({ name: fullName, cpfCnpj: cpfClean, email: emailFull, phone: phoneClean })
    });
    const created = await create.json();
    return created.id;
  }
}

// POST /api/checkout
app.post('/api/checkout', async (req, res) => {
  const {
    fullName,
    cpf,
    emailFull,
    phoneFull,
    paymentMethod,
    shirtSize,
    totalAmount,
    cardNumber,
    cardExpiry,
    cardCvv,
    cardInstallments
  } = req.body;

  try {
    const customerId = await getOrCreateCustomer({ cpf, fullName, emailFull, phoneFull });
    const dueDate = new Date().toISOString().split('T')[0]; // hoje

    let payload = {
      customer: customerId,
      billingType: paymentMethod === 'PIX' ? 'PIX' : 'CREDIT_CARD',
      value: totalAmount,
      dueDate,
      description: `Ingresso Convenção + Camiseta (${shirtSize || 'sem camiseta'})`
    };

    if (paymentMethod === 'CREDIT_CARD') {
      if (!cardNumber || !cardExpiry || !cardCvv || !cardInstallments) {
        return res.status(400).json({ success: false, message: 'Dados de cartão incompletos.' });
      }
      const [expiryMonth, expiryYear] = cardExpiry.split('/');

      payload.installmentCount = parseInt(cardInstallments);
      payload.totalValue = totalAmount;
      payload.creditCard = {
        holderName: fullName,
        number: cardNumber,
        expiryMonth: expiryMonth,
        expiryYear: expiryYear,
        ccv: cardCvv
      };
    } else if (paymentMethod === 'PIX') {
      // Apenas os dados essenciais já estão no payload padrão
    } else {
      return res.status(400).json({ success: false, message: 'Forma de pagamento inválida.' });
    }

    const response = await fetch(`${ASAAS_BASE_URL}/payments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'access_token': ASAAS_API_KEY
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (data.errors) {
      return res.status(400).json({ success: false, message: data.errors[0].description });
    }

    res.json({
      success: true,
      paymentId: data.id, /*insireido para webhook */
      invoiceUrl: data.invoiceUrl || data.bankSlipUrl || data.paymentUrl || null,
      pixQrCode: data.pixQrCode || null
    });
  } catch (err) {
    console.error('Erro no checkout:', err);
    res.status(500).json({ success: false, message: 'Erro interno no servidor.' });
  }
});


app.post('/api/webhook', express.json(), (req, res) => {
  const event = req.body;

  console.log('📩 Webhook recebido:', event.event, 'para pagamento', event.payment?.id);

  // Verificar se o status do pagamento é CONFIRMED
  if (event.payment && event.payment.status === 'CONFIRMED') {
    console.log('✅ Pagamento confirmado com sucesso!', event.payment.id);

    // Aqui você pode salvar o status no banco de dados, arquivo, etc.
    // Exemplo: marcar como pago, liberar ingresso, enviar email, etc.
  }

  res.status(200).send('OK');
});

app.get('/api/status/:id', async (req, res) => {
  const paymentId = req.params.id;

  try {
    const response = await fetch(`${ASAAS_BASE_URL}/payments/${paymentId}`, {
      headers: {
        'access_token': ASAAS_API_KEY
      }
    });

    const data = await response.json();
    res.json({ status: data.status });
  } catch (err) {
    console.error('Erro ao buscar status do pagamento:', err);
    res.status(500).json({ status: 'ERROR' });
  }
});


// Inicializa servidor
const PORT = process.env.PORT || 3000;
 app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));

